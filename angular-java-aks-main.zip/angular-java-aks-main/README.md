# angular-java-ecs
Example Project on how we can deploy Angular with java on AWS ECS
